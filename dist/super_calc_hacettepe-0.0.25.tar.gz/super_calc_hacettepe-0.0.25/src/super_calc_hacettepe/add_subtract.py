def add_two_numbers(num1, num2):
    return num1 + num2

def subtract_two_numbers(num1, num2):
    return num1 - num2

